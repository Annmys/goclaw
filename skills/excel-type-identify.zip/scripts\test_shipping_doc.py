#!/usr/bin/env python3
import json
import re
import sqlite3
import sys
from pathlib import Path

try:
    import xlrd
except Exception:
    xlrd = None

try:
    from openpyxl import load_workbook
except Exception:
    load_workbook = None

from detect_excel_type import detect_type

ORDER_DB = Path(r"D:\数据\包装流转单\全部年份订单映射表.sqlite")


def extract_xs_order_no(path: Path):
    m = re.search(r"(XS\d+)", path.name, re.IGNORECASE)
    return m.group(1).upper() if m else None


def lookup_order_mapping(xs_order_no: str):
    if not ORDER_DB.exists():
        return None
    conn = sqlite3.connect(ORDER_DB)
    try:
        cur = conn.cursor()
        cur.execute(
            "select year_folder, owner_folder, workbook_name, sheet_name, workbook_path from order_mapping where upper(order_no)=upper(?) limit 1",
            (xs_order_no,),
        )
        row = cur.fetchone()
        if not row:
            return None
        return {
            "year_folder": row[0],
            "owner_folder": row[1],
            "workbook_name": row[2],
            "sheet_name": row[3],
            "workbook_path": row[4],
        }
    finally:
        conn.close()


def read_flow_order_outer_box(flow_path: Path, sheet_name: str):
    if flow_path.suffix.lower() == ".xlsx":
        wb = load_workbook(flow_path, read_only=True, data_only=True)
        try:
            ws = wb[sheet_name] if sheet_name in wb.sheetnames else wb[wb.sheetnames[0]]
            rows = ws.iter_rows(values_only=True)
            return extract_outer_box(rows)
        finally:
            wb.close()
    if flow_path.suffix.lower() == ".xls":
        wb = xlrd.open_workbook(str(flow_path), on_demand=True)
        try:
            ws = wb.sheet_by_name(sheet_name) if sheet_name in wb.sheet_names() else wb.sheet_by_index(0)
            rows = ([ws.cell_value(r, c) for c in range(ws.ncols)] for r in range(ws.nrows))
            return extract_outer_box(rows)
        finally:
            wb.release_resources()
    raise RuntimeError("unsupported flow order file")


def extract_outer_box(rows):
    for row_idx, row in enumerate(rows, start=1):
        vals = [str(v).strip() if v not in (None, "") else "" for v in row]
        if "外箱" not in vals:
            continue
        idx = vals.index("外箱")
        spec = vals[idx + 2] if idx + 2 < len(vals) else ""
        qty = vals[idx + 3] if idx + 3 < len(vals) else ""
        return {
            "row": row_idx,
            "outer_box_spec": spec,
            "outer_box_qty": qty,
            "dimension_for_epl": f"{spec}CM*{qty}" if spec and qty else None,
            "c_n_for_epl": f"1-{int(float(qty))}" if qty else None,
        }
    raise RuntimeError("outer box row not found")


def main():
    if len(sys.argv) != 2:
        print("Usage: test_shipping_doc.py <shipping-file>", file=sys.stderr)
        return 2
    shipping_file = Path(sys.argv[1])
    detected = detect_type(shipping_file)
    xs = detected.get("xs_order_no") or extract_xs_order_no(shipping_file)
    mapping = lookup_order_mapping(xs) if xs else None
    result = {
        "shipping_file": str(shipping_file),
        "detected_type": detected.get("detected_type"),
        "xs_order_no": xs,
        "mapping": mapping,
    }
    if mapping:
        outer = read_flow_order_outer_box(Path(mapping["workbook_path"]), mapping["sheet_name"])
        result["outer_box"] = outer
        result["epl_fill_suggestion"] = {
            "packaging_source": "流转单外箱",
            "dimension": outer.get("dimension_for_epl"),
            "c_n": outer.get("c_n_for_epl"),
            "carton_count": outer.get("outer_box_qty"),
        }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
