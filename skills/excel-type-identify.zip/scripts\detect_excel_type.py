#!/usr/bin/env python3
import csv
import json
import re
import sys
from pathlib import Path

try:
    import xlrd
except Exception:
    xlrd = None

try:
    from openpyxl import load_workbook
except Exception:
    load_workbook = None


def read_csv_preview(path: Path):
    rows = []
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        for idx, row in enumerate(reader):
            rows.extend([str(x).strip() for x in row if str(x).strip()])
            if idx >= 9:
                break
    return ["CSV"], rows


def read_xlsx_preview(path: Path):
    wb = load_workbook(path, read_only=True, data_only=True)
    texts = []
    sheets = wb.sheetnames[:]
    try:
        for ws in wb.worksheets[:3]:
            for row in ws.iter_rows(min_row=1, max_row=20, max_col=20, values_only=True):
                texts.extend([str(v).strip() for v in row if v not in (None, "")])
    finally:
        wb.close()
    return sheets, texts


def read_xls_preview(path: Path):
    wb = xlrd.open_workbook(str(path), on_demand=True)
    texts = []
    sheets = wb.sheet_names()
    try:
        for name in sheets[:3]:
            ws = wb.sheet_by_name(name)
            for r in range(min(ws.nrows, 20)):
                for c in range(min(ws.ncols, 20)):
                    v = ws.cell_value(r, c)
                    if v not in ("", None):
                        texts.append(str(v).strip())
    finally:
        wb.release_resources()
    return sheets, texts


def read_preview(path: Path):
    ext = path.suffix.lower()
    if ext == ".csv":
        return read_csv_preview(path)
    if ext == ".xlsx":
        return read_xlsx_preview(path)
    if ext == ".xls":
        return read_xls_preview(path)
    raise RuntimeError(f"unsupported file type: {ext}")


def extract_xs_order_no(path_name: str, texts: list[str]):
    m = re.search(r"(XS\d+)", path_name, re.IGNORECASE)
    if m:
        return m.group(1).upper()
    for t in texts:
        m = re.search(r"(XS\d+)", t, re.IGNORECASE)
        if m:
            return m.group(1).upper()
    return None


def detect_type(path: Path):
    sheets, texts = read_preview(path)
    haystack = "\n".join([path.name, *sheets, *texts]).lower()

    lower_sheets = [s.lower() for s in sheets]
    has_ci = any(name in lower_sheets for name in ["ci", "invoice"])
    has_pl = any(name in lower_sheets for name in ["pl", "epl", "packing list"])
    is_shipping = (has_ci and has_pl) or ("commercial invoice" in haystack and "estimated packing list" in haystack)

    if is_shipping:
        return {
            "file": str(path),
            "detected_type": "船务清单",
            "confidence": "high" if has_ci and has_pl else "medium",
            "sheet_names": sheets,
            "xs_order_no": extract_xs_order_no(path.name, texts),
            "shipping_completeness": {
                "has_ci": has_ci,
                "has_pl": has_pl,
                "packaging_source_rule": "EPL/PL 包装信息应来自对应流转单中的外箱规格和外箱总数",
            },
            "matched_rules": ["同时具备 CI 与 PL/EPL 特征"],
            "next_actions": [
                "检查 CI 是否完整",
                "检查 PL/EPL 是否完整",
                "若需补全，先查订单映射表找到流转单",
                "再以流转单外箱规格和外箱总数作为 EPL 包装信息来源",
            ],
        }

    return {
        "file": str(path),
        "detected_type": "unknown",
        "confidence": "low",
        "sheet_names": sheets,
        "matched_rules": [],
        "next_actions": ["查看表头", "查看 sheet 名称", "确认业务目标后再处理"],
    }


def main():
    if len(sys.argv) != 2:
        print("Usage: detect_excel_type.py <excel-file>", file=sys.stderr)
        return 2
    path = Path(sys.argv[1])
    print(json.dumps(detect_type(path), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

