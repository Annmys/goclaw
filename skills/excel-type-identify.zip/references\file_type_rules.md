# Excel 类型识别规则

## 船务清单

- 同时存在 `CI` 和 `PL/EPL` sheet，或同时出现 `COMMERCIAL INVOICE` 与 `Estimated Packing List`
- 若需要补全：
  - 先查订单映射表
  - 再找流转单
  - `EPL/PL.Dimension` 来自流转单 `外箱` 规格
  - 箱数来自流转单 `外箱` 需求数量
  - `C/N` 根据外箱总数生成

